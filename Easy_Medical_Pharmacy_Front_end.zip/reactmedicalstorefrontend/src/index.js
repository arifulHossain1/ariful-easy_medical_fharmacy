import React from 'react';
import ReactDOM from 'react-dom';
import {BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Login from './pages/login';
import MainComponent from './components/MainComponent';
import { PageCloser } from './utils/PageCloser';
import HomeComponent from './pages/HomeComponent';
import CompanyComponent from './pages/CompanyComponent';
import CompanyDetailComponent from './pages/CompanyDetailComponent';
import LogoutComponent from './pages/LogoutComponent';
import { PageCloserNew } from './utils/PageCloserNew';
import Config from './utils/Config';
import CompanyAddBankComponent from './pages/CompanyAddBankComponent';
import CompanyEditBankComponent from './pages/CompanyEditBankComponent';
import MedicineAddComponent from './pages/MedicineAddComponent';
import MedicineManageComponent from './pages/MedicineManageComponent';


ReactDOM.render(
    <Router>
        <Switch>
            <Route exact path="/" component={Login}></Route>
            <Route exact path={Config.logoutPageUrl} component={LogoutComponent}></Route>
            <PageCloserNew exact path="/home" activepage="0" page={HomeComponent}></PageCloserNew>
            <PageCloserNew exact path="/company" activepage="1" page={CompanyComponent}></PageCloserNew>
            <PageCloserNew exact path="/companydetail/:Id" activepage="1" page={CompanyDetailComponent}></PageCloserNew>
            <PageCloserNew exact path="/addCompanyBank/:Id" activepage="1" page={CompanyAddBankComponent}></PageCloserNew>
            <PageCloserNew exact path="/editCompanyBank/:company_id/:Id" activepage="1" page={CompanyEditBankComponent}></PageCloserNew>
            <PageCloserNew exact path="/addMedicine" activepage="2" page={MedicineAddComponent}></PageCloserNew>
            <PageCloserNew exact path="/manageMedicine" activepage="3" page={MedicineManageComponent}></PageCloserNew>

        </Switch>
    </Router>
    ,document.getElementById("root")
);
