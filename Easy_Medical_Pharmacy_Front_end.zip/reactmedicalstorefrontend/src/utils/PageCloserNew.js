import React, { Component } from 'react';
import { Redirect, Route } from 'react-router';
import MainComponent from '../components/MainComponent';
import AuthHandler from './AuthHandler';

export var PageCloserNew=({page, activepage,...rest }) =>(
    <Route
    {...rest}
    render={(props) => AuthHandler.loggedIn() ? (<MainComponent page={page} activepage={activepage} {...props} />) : <Redirect to='/' />}
    />
);