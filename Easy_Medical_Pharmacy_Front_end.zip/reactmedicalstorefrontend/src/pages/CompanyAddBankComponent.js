import React from 'react';
import { Link } from 'react-router-dom';
import APIHandler from '../utils/APIHandler';
import AuthHandler from '../utils/AuthHandler';

class CompanyAddBankComponent extends React.Component {

    constructor(props) {
        super(props)
        this.formSubmit = this.formSubmit.bind(this);
    }

    state = {
        errorRes: false,
        errorMessage: "",
        btnMessage: 0,
        sendData: false,
    }

    async formSubmit(event) {
        event.preventDefault();
        this.setState({ btnMessage: 1 });
        var apiHandler = new APIHandler();
        var response = await apiHandler.saveCompanayBankData(event.target.bank_account_number.value,event.target.ifsc_number.value,this.props.match.params.Id);
        console.log(response);
        this.setState({ btnMessage: 0 });
        this.setState({ errorRes: response.data.error })
        this.setState({ errorMessage: response.data.message })
        this.setState({ sendData: true });
    }


    render() {
        return (
            <section className="content">
                <div className="container-fluid">
                    <div className="block-header">
                        <h2>COMPANY BANK DETAIL</h2>
                    </div>
                    <div className="row clearfix">
                        <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div className="card">
                                <div className="header">
                                    {this.state.dataLoaded == false ? (
                                        <div className="text-center">
                                            <div class="preloader pl-size-xl">
                                                <div class="spinner-layer">
                                                    <div class="circle-clipper left">
                                                        <div class="circle"></div>
                                                    </div>
                                                    <div class="circle-clipper right">
                                                        <div class="circle"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    ) : ""}
                                    <h2>
                                        ADD COMPANY BANK #{this.props.match.params.Id}
                                    </h2>
                                </div>
                                <div className="body">
                                    <form onSubmit={this.formSubmit}>
                                        <label htmlFor="email_address">Bank Account No</label>
                                        <div className="form-group">
                                            <div className="form-line">
                                                <input type="text" id="bank_account_number" name="bank_account_number" className="form-control" placeholder="Enter Company Account Number" />
                                            </div>
                                        </div>
                                        <label htmlFor="email_address">BFSC No</label>
                                        <div className="form-group">
                                            <div className="form-line">
                                                <input type="text" id="ifsc_number" name="ifsc_number" className="form-control" placeholder="Enter Company BFSC No" />
                                            </div>
                                        </div>
                                        <br />
                                        <button type="submit" className="btn btn-primary m-t-15 waves-effect btn-effect" disabled={this.state.btnMessage == 0 ? false : true}>{this.state.btnMessage == 0 ? "Add Company Bank" : "Adding Company Bank Please Wait..."}</button>

                                        <br />
                                        {this.state.errorRes == false && this.state.sendData == true ? (
                                            <div className="alert alert-success">
                                                <strong>Success!</strong> {this.state.errorMessage}.
                                                <Link to={"/companydetail/"+ this.props.match.params.Id} className="btn btn-info">Back to Previous Page</Link>
                                            </div>
                                        ) : ""
                                        }
                                        {this.state.errorRes == true && this.state.sendData == true ? (
                                            <div className="alert alert-danger">
                                                <strong>Failed!</strong> {this.state.errorMessage}.
                                            </div>
                                        ) : ""
                                        }

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section >
        );
    }
}

export default CompanyAddBankComponent;