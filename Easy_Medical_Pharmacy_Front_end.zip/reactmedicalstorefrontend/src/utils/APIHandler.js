
import axios from 'axios'
import React from 'react'
import { reactLocalStorage } from 'reactjs-localstorage';
import AuthHandler from './AuthHandler'
import Config from './Config'

class APIHandler {
    async checkLogin() {
        if (AuthHandler.checkTokenExpiry()) {
            try{
            var response = await axios.post(Config.refreshApiUrl, { refresh: AuthHandler.getRefreshToken() });
            reactLocalStorage.set("token", response.data.access);
        } catch(error) {
            console.log(error);
            AuthHandler.logoutUser();
            window.location="/";
        }
    }
    }
    async saveCompanayData(name, license_no, address, contact_no, email, description) {
        await this.checkLogin();
        var response = await axios.post(Config.companyApiUrl, { name: name, license_no: license_no, address: address, contact_no: contact_no, email: email, description: description }, { headers: { Authorization: "Bearer " + AuthHandler.getLoginToken() } });
        return response;
    }

    async fetchAllCompany(){
        await this.checkLogin();

        var response=await axios.get(Config.companyApiUrl,{headers:{Authorization:"Bearer "+AuthHandler.getLoginToken()}});
        return response;
    }

    async fetchCompanyDetail(Id){
        await this.checkLogin();

        var response=await axios.get(Config.companyApiUrl+""+Id+"/",{headers:{Authorization:"Bearer "+AuthHandler.getLoginToken()}});
        return response;
    }

    async editCompanayData(name, license_no, address, contact_no, email, description, Id) {
        await this.checkLogin();
        var response = await axios.put(Config.companyApiUrl+""+Id+"/", { name: name, license_no: license_no, address: address, contact_no: contact_no, email: email, description: description }, { headers: { Authorization: "Bearer " + AuthHandler.getLoginToken() } });
        return response;
    }

    async saveCompanayBankData(bank_account_number,ifsc_number,company_id) {
        await this.checkLogin();
        var response = await axios.post(Config.companybankApiUrl, {bank_account_number: bank_account_number,ifsc_number:ifsc_number, company_id: company_id  }, { headers: { Authorization: "Bearer " + AuthHandler.getLoginToken() } });
        return response;
    }

    async fetchCompanyBankDetail(Id){
        await this.checkLogin();

        var response=await axios.get(Config.companybankApiUrl+""+Id+"/",{headers:{Authorization:"Bearer "+AuthHandler.getLoginToken()}});
        return response;
    }

    async editCompanayBankData(bank_account_number,ifsc_number,company_id,Id) {
        await this.checkLogin();
        var response = await axios.put(Config.companybankApiUrl+""+Id+"/", { bank_account_number:bank_account_number , ifsc_number: ifsc_number, company_id:company_id }, { headers: { Authorization: "Bearer " + AuthHandler.getLoginToken() } });
        return response;
    }

    async fetchCompanyonly(){
        await this.checkLogin();

        var response=await axios.get(Config.companyonlyApiUrl,{headers:{Authorization:"Bearer "+AuthHandler.getLoginToken()}});
        return response;
    }

    async saveMedicineData(name, medical_type, buy_price, sell_price, batch_no, shelf_no, exp_date, mfg_date, company_id, description, in_stock_total, qty_in_strip, medicinedetails){
        await this.checkLogin();
        var response = await axios.post(Config.medicineApiUrl, { name: name, medical_type: medical_type, buy_price: buy_price, sell_price: sell_price, batch_no: batch_no, shelf_no: shelf_no, exp_date: exp_date, mfg_date: mfg_date, company_id: company_id, description: description, in_stock_total: in_stock_total, qty_in_strip: qty_in_strip, medicine_details: medicinedetails }, { headers: { Authorization: "Bearer " + AuthHandler.getLoginToken() } });
        return response;

    }

    async fetchAllMedicine(){
        await this.checkLogin();

        var response=await axios.get(Config.medicineApiUrl,{headers:{Authorization:"Bearer "+AuthHandler.getLoginToken()}});
        return response;
    }

    async editMedicineData(name, medical_type, buy_price, sell_price, batch_no, shelf_no, exp_date, mfg_date, company_id, description, in_stock_total, qty_in_strip, medicinedetails,Id){
        await this.checkLogin();
        var response = await axios.put(Config.medicineApiUrl+""+Id+"/", { name: name, medical_type: medical_type, buy_price: buy_price, sell_price: sell_price, batch_no: batch_no, shelf_no: shelf_no, exp_date: exp_date, mfg_date: mfg_date, company_id: company_id, description: description, in_stock_total: in_stock_total, qty_in_strip: qty_in_strip, medicine_details: medicinedetails }, { headers: { Authorization: "Bearer " + AuthHandler.getLoginToken() } });
        return response;

    }


}

export default APIHandler;