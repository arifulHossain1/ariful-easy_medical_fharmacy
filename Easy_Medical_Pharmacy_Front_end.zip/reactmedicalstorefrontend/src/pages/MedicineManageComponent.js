import React from 'react';
import { Link } from 'react-router-dom';
import APIHandler from '../utils/APIHandler';
import AuthHandler from '../utils/AuthHandler';

class MedicineManageComponent extends React.Component {

    constructor(props) {
        super(props)
        this.formSubmit = this.formSubmit.bind(this);
    }

    state = {
        errorRes: false,
        errorMessage: "",
        btnMessage: 0,
        sendData: false,
        companylist: [],
        medicinedetails: [],
        medicineDataList: [],
        dataLoaded: false,
        name:"", 
        medical_type:"", 
        buy_price:"", 
        sell_price:"", 
        batch_no:"", 
        shelf_no:"", 
        exp_date:"", 
        mfg_date:"", 
        company_id:"", 
        description1:"", 
        in_stock_total:"", 
        qty_in_strip:"",
        total_salt_list:0,
        medicine_id:0,
    }

    async formSubmit(event) {
        event.preventDefault();
        this.setState({ btnMessage: 1 });
        var apiHandler = new APIHandler();
        var response = await apiHandler.editMedicineData(event.target.name.value, event.target.medical_type.value, event.target.buy_price.value, event.target.sell_price.value, event.target.batch_no.value, event.target.shelf_no.value, event.target.exp_date.value, event.target.mfg_date.value, event.target.company_id.value, event.target.description1.value, event.target.in_stock_total.value, event.target.qty_in_strip.value, this.state.medicinedetails, this.state.medicine_id);
        console.log(response);
        this.setState({ btnMessage: 0 });
        this.setState({ errorRes: response.data.error })
        this.setState({ errorMessage: response.data.message })
        this.setState({ sendData: true });
    }

    componentDidMount() {
        this.LoadInitalData();

    }
    async LoadInitalData() {
        var apiHandler = new APIHandler();
        var companydata = await apiHandler.fetchCompanyonly();
        var medicinedata= await apiHandler.fetchAllMedicine();
        this.setState({ companylist: companydata.data });
        this.setState({medicineDataList:medicinedata.data.data});
        this.setState({dataLoaded:true});
    }

    RemoveItem=()=>{
        if(this.state.medicinedetails.length != this.state.total_salt_list){
        this.state.medicinedetails.pop(this.state.medicinedetails.length-1);
        }
        this.setState({});
    }
    handleInput=(event)=>{
        var keyname=event.target.name;
        var value=event.target.value;
        var index=event.target.getAttribute("data-index");
        this.state.medicinedetails[index][keyname]=value;
        this.setState({});
        console.log(this.state.medicinedetails);
    }

    AddItem=()=>{
        var item= { "salt_name": "", "salt_qty": "", "salt_qty_type": "", "description": "", "Id":0, };
        this.state.medicinedetails.push(item);
        this.setState({});
    }

    viewmedicineDetails=(index)=>{
        console.log(this.state.medicineDataList[index]);
        this.setState({medicine_id: this.state.medicineDataList[index].Id})
        this.setState({name: this.state.medicineDataList[index].name}); 
        this.setState({medical_type: this.state.medicineDataList[index].medical_type}); 
        this.setState({buy_price: this.state.medicineDataList[index].buy_price});
        this.setState({sell_price: this.state.medicineDataList[index].sell_price}); 
        this.setState({batch_no: this.state.medicineDataList[index].batch_no}); 
        this.setState({shelf_no: this.state.medicineDataList[index].shelf_no}); 
        this.setState({exp_date: this.state.medicineDataList[index].exp_date}); 
        this.setState({mfg_date: this.state.medicineDataList[index].mfg_date}); 
        this.setState({company_id: this.state.medicineDataList[index].company_id});
        this.setState({description1: this.state.medicineDataList[index].description}); 
        this.setState({in_stock_total: this.state.medicineDataList[index].in_stock_total}); 
        this.setState({qty_in_strip: this.state.medicineDataList[index].qty_in_strip});
        this.setState({total_salt_list: this.state.medicineDataList[index].medicine_details.lenght});
        this.setState({medicinedetails: this.state.medicineDataList[index].medicine_details});
    }


    render() {
        return (
            <section className="content">
                <div className="container-fluid">
                    <div className="block-header">
                        <h2>MANAGE MEDICINE</h2>
                    </div>
                    <div className="row clearfix">
                        <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div className="card">
                                <div className="header">
                                    {this.state.dataLoaded == false ? (
                                        <div className="text-center">
                                            <div class="preloader pl-size-xl">
                                                <div class="spinner-layer">
                                                    <div class="circle-clipper left">
                                                        <div class="circle"></div>
                                                    </div>
                                                    <div class="circle-clipper right">
                                                        <div class="circle"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    ) : ""}
                                    <h2>
                                        ALL MEDICINE
                            </h2>
                                </div>
                                <div className="body table-responsive">
                                    <table className="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>#ID</th>
                                                <th>Name</th>
                                                <th>Medicine Type</th>
                                                <th>Buy Price</th>
                                                <th>Sell Price</th>
                                                <th>Batch No</th>
                                                <th>Shelf No</th>
                                                <th>Exp Date</th>
                                                <th>MFG Date</th>
                                                <th>Company</th>
                                                <th>Description</th>
                                                <th>In Stock Total</th>
                                                <th>Qty In Strip</th>
                                                <th>Added On</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {this.state.medicineDataList.map((medicine,index) => (
                                                <tr key={medicine.Id}>
                                                    <td>{medicine.Id}</td>
                                                    <td>{medicine.name}</td>
                                                    <td>{medicine.medical_type}</td>
                                                    <td>{medicine.buy_price}</td>
                                                    <td>{medicine.sell_price}</td>
                                                    <td>{medicine.batch_no}</td>
                                                    <td>{medicine.shelf_no}</td>
                                                    <td>{medicine.exp_date}</td>
                                                    <td>{medicine.mfg_date}</td>
                                                    <td>{medicine.company.name}</td>
                                                    <td>{medicine.description}</td>
                                                    <td>{medicine.in_stock_total}</td>
                                                    <td>{medicine.qty_in_strip}</td>
                                                    <td>{new Date(medicine.added_on).toLocaleString()}</td>
                                                    <td><button className="btn btn-block btn-warning" onClick={() => this.viewmedicineDetails(index)}>View Data</button></td>
                                                </tr>

                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="row clearfix">
                        <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div className="card">
                                <div className="header">
                                    {this.state.dataLoaded == false ? (
                                        <div className="text-center">
                                            <div class="preloader pl-size-xl">
                                                <div class="spinner-layer">
                                                    <div class="circle-clipper left">
                                                        <div class="circle"></div>
                                                    </div>
                                                    <div class="circle-clipper right">
                                                        <div class="circle"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    ) : ""}
                                    <h2>
                                        MANAGE MEDICINE
                                    </h2>
                                </div>
                                <div className="body">
                                    <form onSubmit={this.formSubmit}>
                                        <label htmlFor="email_address">Medicine Name</label>
                                        <div className="form-group">
                                            <div className="form-line">
                                                <input type="text" id="name" name="name" className="form-control" placeholder="Enter Medicine Name" defaultValue={this.state.name} />
                                            </div>
                                        </div>
                                        <label htmlFor="email_address">Medicine Type</label>
                                        <div className="form-group">
                                            <div className="form-line">
                                                <input type="text" id="medical_type" name="medical_type" className="form-control" placeholder="Enter Medicine Type" defaultValue={this.state.medical_type}/>
                                            </div>
                                        </div>
                                        <label htmlFor="email_address">Buy Price</label>
                                        <div className="form-group">
                                            <div className="form-line">
                                                <input type="text" id="buy_price" name="buy_price" className="form-control" placeholder="Enter buy price of Medicine" defaultValue={this.state.buy_price}/>
                                            </div>
                                        </div>
                                        <label htmlFor="email_address">Sell Price</label>
                                        <div className="form-group">
                                            <div className="form-line">
                                                <input type="text" id="sell_price" name="sell_price" className="form-control" placeholder="Enter sell price of Medicine" defaultValue={this.state.sell_price}/>
                                            </div>
                                        </div>
                                        <label htmlFor="email_address">Batch No</label>
                                        <div className="form-group">
                                            <div className="form-line">
                                                <input type="text" id="batch_no" name="batch_no" className="form-control" placeholder="Enter Batch No of Medicine" defaultValue={this.state.batch_no}/>
                                            </div>
                                        </div>
                                        <label htmlFor="email_address">Shelf No</label>
                                        <div className="form-group">
                                            <div className="form-line">
                                                <input type="text" id="shelf_no" name="shelf_no" className="form-control" placeholder="Enter Shelf No" defaultValue={this.state.shelf_no}/>
                                            </div>
                                        </div>
                                        <label htmlFor="email_address">Expire Date</label>
                                        <div className="form-group">
                                            <div className="form-line">
                                                <input type="date" id="exp_date" name="exp_date" className="form-control" placeholder="Enter Expire Date" defaultValue={this.state.exp_date}/>
                                            </div>
                                        </div>
                                        <label htmlFor="email_address">Mfg Date</label>
                                        <div className="form-group">
                                            <div className="form-line">
                                                <input type="date" id="mfg_date" name="mfg_date" className="form-control" placeholder="Enter Mfg Date" defaultValue={this.state.mfg_date}/>
                                            </div>
                                        </div>
                                        <label htmlFor="email_address">Description</label>
                                        <div className="form-group">
                                            <div className="form-line">
                                                <input type="text" id="description1" name="description1" className="form-control" placeholder="Enter Medicine Description" defaultValue={this.state.description1}/>
                                            </div>
                                        </div>
                                        <label htmlFor="email_address">Total Stock</label>
                                        <div className="form-group">
                                            <div className="form-line">
                                                <input type="text" id="in_stock_total" name="in_stock_total" className="form-control" placeholder="Enter Total Stock" defaultValue={this.state.in_stock_total}/>
                                            </div>
                                        </div>
                                        <label htmlFor="email_address">Qty in Strip</label>
                                        <div className="form-group">
                                            <div className="form-line">
                                                <input type="text" id="qty_in_strip" name="qty_in_strip" className="form-control" placeholder="Enter Qty in strip" defaultValue={this.state.qty_in_strip}/>
                                            </div>
                                        </div>
                                        <label htmlFor="email_address">Company</label>
                                        <div className="form-group">
                                            <select className="form-control show-tick" name="company_id" id="company_id">
                                                {this.state.companylist.map((item) => (
                                                    <option key={item.Id} value={item.Id} selected={(item.Id==this.state.company_id?true:false)}>{item.name} 
                                                    </option>
                                                ))}
                                            </select>
                                        </div>
                                        <div className="form-group">
                                            <div className="col-lg-6">
                                                <button className="btn btn-block btn-success" type="button" onClick={this.AddItem}>Add Details</button>
                                            </div>
                                            <div className="col-lg-6">
                                                <button className="btn btn-block btn-danger" type="button" onClick={this.RemoveItem}>Remove Details</button>
                                            </div>
                                        </div>
                                        {this.state.medicinedetails.map((item,index) => (
                                            <div className="form-group row" key={index}>
                                                <div className="col-lg-3">
                                                    <label htmlFor="email_address">Salt Name</label>
                                                    <div className="form-line">
                                                        <input type="text" id="salt_name" name="salt_name" className="form-control" placeholder="Enter Salt Name" onChange={this.handleInput} data-index={index} Value={item.salt_name}/>
                                                    </div>
                                                </div>
                                                <div className="col-lg-3">
                                                    <label htmlFor="email_address">Salt Qty</label>
                                                    <div className="form-line">
                                                        <input type="text" id="salt_qty" name="salt_qty" className="form-control" placeholder="Enter Salt Qty" onChange={this.handleInput} data-index={index} Value={item.salt_qty}/>
                                                    </div>
                                                </div>
                                                <div className="col-lg-3">
                                                    <label htmlFor="email_address">Salt Qty Type</label>
                                                    <div className="form-line">
                                                        <input type="text" id="salt_qty_type" name="salt_qty_type" className="form-control" placeholder="Enter Salt Qty Type" onChange={this.handleInput} data-index={index} Value={item.salt_qty_type}/>
                                                    </div>
                                                </div>
                                                <div className="col-lg-3">
                                                    <label htmlFor="email_address">Description</label>
                                                    <div className="form-line">
                                                        <input type="text" id="description" name="description" className="form-control" placeholder="Enter Description" onChange={this.handleInput} data-index={index} Value={item.description}/>
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                        <br />
                                        <button type="submit" className="btn btn-primary m-t-15 waves-effect btn-effect" disabled={this.state.btnMessage == 0 ? false : true}>{this.state.btnMessage == 0 ? "Edit Medicine" : "Updating Medicine Please Wait..."}</button>

                                        <br />
                                        {this.state.errorRes == false && this.state.sendData == true ? (
                                            <div className="alert alert-success">
                                                <strong>Success!</strong> {this.state.errorMessage}.
                                            </div>
                                        ) : ""
                                        }
                                        {this.state.errorRes == true && this.state.sendData == true ? (
                                            <div className="alert alert-danger">
                                                <strong>Failed!</strong> {this.state.errorMessage}.
                                            </div>
                                        ) : ""
                                        }

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section >
        );
    }
}

export default MedicineManageComponent;