import React, { Component } from 'react';
import { Redirect, Route } from 'react-router';
import AuthHandler from './AuthHandler';

export var PageCloser=({component:Component,...rest}) =>(
    <Route
    {...rest}
    render={(props) => AuthHandler.loggedIn() ? (<Component {...props} />) : <Redirect to='/' />}
    />
);