from django.apps import AppConfig


class EasyfharmacyConfig(AppConfig):
    name = 'EasyFharmacy'
